# Maryam Ajike Sulyman – Simple Portfolio

This folder contains a simple one-page portfolio website.

Before publishing:
1. Open `index.html`.
2. Replace `YOUR_EMAIL_HERE` with your email.
3. Replace `YOUR_X_USERNAME_HERE` with your X profile/username.
4. Upload `index.html` to a free hosting service such as GitHub Pages or Netlify.

The published website URL can then be pasted into an application form asking for a portfolio link.
